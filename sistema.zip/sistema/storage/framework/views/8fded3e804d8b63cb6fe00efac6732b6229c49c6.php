<?php $__env->startSection('titulo'); ?>
Vídeo Aula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Vídeo Aulas</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>