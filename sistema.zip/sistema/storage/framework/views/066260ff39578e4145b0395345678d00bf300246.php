<?php $__env->startSection('titulo'); ?>
Serviços
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

<h3>Todos os serviços</h3>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="bgc-white bd bdrs-3 p-20 mB-20 table-responsive-sm">
                <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Titulo</th>
                            <th>Variação de preço</th>
                            <th>Tipo de serviço</th>
                            <th>Autônomo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $servico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($s->nome); ?></td>
                            <td>R$ <?php echo e($s->menor_preco); ?> ~ R$ <?php echo e($s->maior_preco); ?></td>
                            <td><?php echo e($s->tipo_servico->nome); ?></td>
                            <td><?php echo e(collect(explode(' ', $s->user->name))->slice(0, 3)->implode(' ')); ?></td>
                            <td><a href="<?php echo e(url('servico/contratar/'.$s->id)); ?>" class="btn btn-primary btn-block" title="Clique para ver mais detalhes">Detalhar</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>