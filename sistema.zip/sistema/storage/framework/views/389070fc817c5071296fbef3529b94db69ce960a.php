<?php $__env->startSection('titulo'); ?>
Cadastrar novo serviço
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h3>Cadastrar novo serviço</h3>

<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <form method="post" action="<?php echo e(url('servico/store')); ?>" enctype="multipart/form-data">
                <div class="form-row">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group col-md-6"><label for="nome">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome" required>
                    </div>
                    <div class="form-group col-md-6"><label for="tipo">Tipo</label>
                        <select class="form-control" id="tipo" name="tipo" required>
                            <option>Selecione</option>
                            <?php $__currentLoopData = $tipo_servico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6"><label for="menor_preco">Menor preço</label>
                        <input type="text" class="form-control money2" id="menor_preco" name="menor_preco" value="0.00" required>
                    </div>
                    <div class="form-group col-md-6"><label for="maior_preco">Maior preço</label>
                        <input type="text" class="form-control money2" id="maior_preco" name="maior_preco" value="0.00" required>
                    </div>
                    <div class="form-group col-md-6"><label for="descricao">Descrição</label>
                        <textarea class="form-control" id="descricao" name="descricao" cols="20" rows="10" required></textarea>
                    </div>
                </div>
                <div class="form-group">
                </div><button type="submit" class="btn btn-primary">Salvar</button>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>