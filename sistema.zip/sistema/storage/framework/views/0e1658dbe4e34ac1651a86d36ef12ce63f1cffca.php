<tr>
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
            <tr>
                <td class="content-cell" align="center">
                    © 2020 Mercado de Serviços. Todos os direitos reservados.
                </td>
            </tr>
        </table>
    </td>
</tr>