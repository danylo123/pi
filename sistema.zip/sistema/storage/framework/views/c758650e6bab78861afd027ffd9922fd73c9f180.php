<?php $__env->startSection('titulo'); ?>
Cadastro usuário
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h3>Cadastro usuário</h3>
<?php if(!empty($mensagem)): ?>
<div class="alert alert-success">Usuário inserido com sucesso!</div>
<?php endif; ?>
<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <form method="post" action="<?php echo e(url('usuario/store')); ?>" enctype="application/x-www-form-urlencoded">
                <div class="form-row">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="form-group col-md-6"><label for="nome">Nome</label>
                        <input type="text" class="form-control" id="nome" name="name" maxlength="30" placeholder="Nome">
                    </div>
                    <div class="form-group col-md-6"><label for="cpf">CPF</label>
                        <input type="text" class="form-control cpf" id="cpf" name="cpf" maxlength="11" placeholder="CPF">
                    </div>
                    <div class="form-group col-md-6"><label for="email">E-mail</label>
                        <input type="email" class="form-control" id="email" maxlength="60" name="email" placeholder="E-mail">
                    </div>
                    <div class="form-group col-md-6"><label for="senha">Senha</label>
                        <input type="password" class="form-control" id="senha" maxlength="8" name="password" placeholder="Senha">
                    </div>
                    <div class="form-group col-md-6"><label for="telefone">Telefone</label>
                        <input type="text" class="form-control phone" id="phone" name="telefone" placeholder="Telefone">
                    </div>                    
                    <div class="form-group col-md-6"><label for="nivel">Nivel de permissão</label>
                        <select class="form-control" id="nivel" name="nivel">
                            <option>Selecione</option>
                            <?php $__currentLoopData = $nivel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($n->id); ?>"><?php echo e($n->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
        </div>
    </div>
</div>
<div class="form-group">
</div><button type="submit" class="btn btn-primary">Salvar</button>
</form>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>