<?php $__env->startSection('titulo'); ?>
Cadastro Imagens para serviço
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h3>Cadastrar imagens para serviço</h3>

<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30 card col-sm-7">
            <form method="post" action="<?php echo e(url('servico/imagem/store')); ?>" enctype="multipart/form-data">
                <div class="form-row">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="servico_id" value="<?php echo e($servico_id); ?>">

                    <div class="form-group col-md-6"><label for="arquivo">Adicionar imagem</label><br>
                        <input type="file" name="arquivo" id="arquivo" multiple="multiple">
                    </div>
                    <div class="form-group col-sm-6"><label for="arquivo"></label><br>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </div>
            </form>
        </div>
        <br>
        <div class="row">
            <?php $__currentLoopData = $imagem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>​
            <div class="card col-sm-4">
                <img class="rounded" height="230px" src="<?php echo e(url('storage/servicos/'.$i->arquivo)); ?>">
                <div class="card-img-overlay">
                    <a href="<?php echo e(url('servico/imagem/destroy/'.$i->id)); ?>" class="btn" style="background-color: white;" title="Remover imagem"><i class="ti-trash"></i></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>