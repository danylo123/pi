<?php $__env->startSection('titulo'); ?>
Editar usuário
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h3>Editar usuário</h3>
<?php if(!empty($mensagem)): ?>
<div class="alert alert-success">Usuário inserido com sucesso!</div>
<?php endif; ?>
<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <form method="post" action="<?php echo e(url('usuario/alterar')); ?>" enctype="application/x-www-form-urlencoded">
                <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="form-row">
                    <div class="form-group col-md-6"><label for="nome">Nome</label>
                        <input type="text" class="form-control" id="nome" name="name" maxlength="30" value="<?php echo e($u->name); ?>" placeholder="Nome">
                    </div>
                    <input type="hidden" id="id" name="id" class="form-control" required value="<?php echo e($u->id); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group col-md-6"><label for="cpf">CPF</label>
                        <input type="text" class="form-control cpf" id="cpf" name="cpf" value="<?php echo e($u->cpf); ?>" placeholder="CPF">
                    </div>
                    <div class="form-group col-md-6"><label for="email">E-mail</label>
                        <input type="email" class="form-control" id="email" name="email" maxlength="60" value="<?php echo e($u->email); ?>" placeholder="E-mail">
                    </div>
                    <div class="form-group col-md-6"><label for="senha">Senha</label>
                        <input type="password" class="form-control" id="password" name="password" maxlength="8" placeholder="Senha">
                    </div>
                    <div class="form-group col-md-6"><label for="telefone">Telefone</label>
                        <input type="text" class="form-control phone" id="telefone" name="telefone" value="<?php echo e($u->telefone); ?>" placeholder="Telefone">
                    </div>
                    <div class="form-group col-md-6"><label for="nivel">Nivel de permissão</label>
                        <select class="form-control" id="nivel" name="nivel_id">
                            <?php $__currentLoopData = $nivel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($n->id); ?>" <?php if($n->id == $u->nivel_id): ?> selected <?php endif; ?>><?php echo e($n->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-row">

                </div>
                <div class="form-group">
                </div><button type="submit" class="btn btn-primary">Salvar</button>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>