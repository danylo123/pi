<?php $__env->startSection('titulo'); ?>
Estrutura Administrativa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h3>Estrutura Administrativa</h3>

<div class="masonry-item w-100">
    <div class="row gap-20">
        <div class="col-md-3">
            <div class="layers bd bgc-white p-20">
                <div class="layer w-100 mB-10">
                    <h6 class="lh-1">Nome</h6>
                    <h6 class="lh-1">Cargo</h6>
                </div>
                <div class="layer w-100">
                    <div class="peers ai-sb fxw-nw">                        
                        <div class="peer"><img src="<?php echo e(Storage:url("app/public/estrutura_administrativa/user.jpg")); ?>"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>