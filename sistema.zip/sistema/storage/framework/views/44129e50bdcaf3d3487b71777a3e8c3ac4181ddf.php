<?php $__env->startSection('titulo'); ?>
Ouvidoria
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Administrar chamados ouvidoria</h1>
<div class="masonry-item col-md-12">

</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="bgc-white bd bdrs-3 p-20 mB-20 table-responsive-sm">
                <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Cód.</th>
                            <th>Assunto</th>
                            <th>Usuário</th>
                            <th>Estado</th>
                            <th>Ultima mudança</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ouvidoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($o->id); ?></td>
                            <td><?php echo e($o->assunto); ?></td>
                            <td><?php echo e($o->user->name); ?></td>
                            <td>
                                <?php if($o->estado == "Concluido"): ?>
                                <span class="badge badge-success" title="<?php echo e(date_format($o->updated_at, 'd/m/Y H:i:s')); ?>">
                                    <?php echo e($o->estado); ?>

                                </span>
                                <?php else: ?>
                                <span class="badge badge-warning" title="<?php echo e(date_format($o->updated_at, 'd/m/Y H:i:s')); ?>">
                                    <?php echo e($o->estado); ?>

                                </span>
                                <?php endif; ?>
                            </td>                            
                            <td><a href="<?php echo e(url('ouvidoria/chamado/'.$o->id)); ?>" class="btn btn-primary btn-block" title="Clique para ver mais detalhes">Destalhar</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>