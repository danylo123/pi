<?php $__env->startSection('titulo'); ?>
Contratar serviço
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h3>Contratar serviço</h3>

<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <div class="row">
                <?php $__currentLoopData = $servico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-5">
                    <div id="carouselExampleIndicators<?php echo e($s->id); ?>" class="carousel slide card-img-top" data-ride="carousel">
                        <ol class="carousel-indicators">

                            <?php $__currentLoopData = $s->arquivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-target="#carouselExampleIndicators<?php echo e($s->id); ?>" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>

                        <div class="carousel-inner">
                            <?php $__currentLoopData = $s->arquivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($loop->first ? ' active' : ''); ?>">
                                <img class="d-block w-100 col-md-12" height="300px" src="<?php echo e(url('storage/servicos/'.$i->arquivo)); ?>" alt="<?php echo e($s->nome); ?>">
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <a class="carousel-control-prev" href="#carouselExampleIndicators<?php echo e($s->id); ?>" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Anterior</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators<?php echo e($s->id); ?>" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Próximo</span>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Serviço: <?php echo e($s->nome); ?></h5>
                    <p class="card-text">Categoria: <?php echo e($s->tipo_servico->nome); ?></p>
                    <p class="card-text">Descrição: <?php echo e($s->descricao); ?></p>
                    <p class="card-text">Variação de preço: R$<?php echo e($s->menor_preco); ?> e R$<?php echo e($s->maior_preco); ?></p>
                    <p class="card-text">Autonomo: <?php echo e($s->user->name); ?></p>
                    <form method="post" action="<?php echo e(url('servico/contratar/store')); ?>">
                        <div class="form-row">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <?php $__currentLoopData = $servico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="servico_id" value="<?php echo e($s->id); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                        </div>
                        <div class="form-group">
                        </div><button type="submit" class="btn btn-primary">Solicitar orçamento</button>
                    </form>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>