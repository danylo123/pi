<?php $__env->startSection('titulo'); ?>
Galeria GME's
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Galeria GME's</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>