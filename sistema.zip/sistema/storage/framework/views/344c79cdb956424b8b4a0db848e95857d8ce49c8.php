<?php $__env->startSection('titulo'); ?>
Perfil endereço
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Endereço</h1>

<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <form method="post" action="<?php echo e(url('perfil/endereco/store')); ?>" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">

                <div class="form-row">
                    <?php $__currentLoopData = $endereco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group col-md-6"><label for="rua">Rua</label>
                        <input type="text" class="form-control" id="rua" name="rua" value="<?php echo e($e->rua); ?>" required placeholder="Rua">
                    </div>
                    <div class="form-group col-md-6"><label for="numero">Número</label>
                        <input type="text" class="form-control" id="numero" name="numero" value="<?php echo e($e->numero); ?>" required placeholder="numero">
                    </div>
                    <div class="form-group col-md-6"><label for="bairro">Bairro</label>
                        <input type="text" class="form-control" id="bairro" name="bairro" value="<?php echo e($e->bairro); ?>" required placeholder="Bairro">
                    </div>
                    <div class="form-group col-md-6"><label for="cidade">Cidade</label>
                        <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo e($e->cidade); ?>" required placeholder="Cidade">
                    </div>
                    <div class="form-group col-md-6"><label for="estado">Estado / UF</label>
                        <input type="text" class="form-control" id="estado" name="estado" value="<?php echo e($e->estado); ?>" placeholder="Estado">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="form-group">
                </div><button type="submit" class="btn btn-primary">Salvar</button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>