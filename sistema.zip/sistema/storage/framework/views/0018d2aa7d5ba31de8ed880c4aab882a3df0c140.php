<?php $__env->startSection('titulo'); ?>
Serviços
<?php $__env->stopSection(); ?>


<?php $__env->startSection('conteudo'); ?>

<h2 class="display-4 text-black">Serviços</h2>
<p class="lead text-black mb-0">Ache o que você precisa aqui.</p>
<div class="justify-content-center">
    <form action="<?php echo e(route('procurar')); ?>" method="get" class="form-horizontal">

        <div class="row">
            <input class="form-control col-sm-11" type="text" name="txt" id="txt" placeholder="Pesquisar">
            <button type="submit" class="btn btn-dark">
                Buscar
            </button>
        </div>
    </form>
</div>
<br>
<?php if(Route::current()->getName() == 'procurar'): ?>
<p class="lead">Exibindo <b><?php echo e($servico->count()); ?></b> resultados sobre "<b><?php echo e($busca); ?></b>"</p>
<?php endif; ?>
<?php $__currentLoopData = $servico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="media bg-light well col-md-12 rounded">
    <div id="carouselExampleControls<?php echo e($s->id); ?>" class="carousel align-self-center col-3" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php $__currentLoopData = $s->arquivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-target="#carouselExampleIndicators<?php echo e($s->id); ?>" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <div class="carousel-inner" role="listbox" style="height: 12rem;">
            <?php if(count($s->arquivo) == 0): ?>
            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                <img class="img-fluid" style="height: 50%; width:60%;" src="<?php echo e(url('storage/servicos/default.jpg')); ?>" alt="<?php echo e($s->nome); ?>">
            </div>
            <?php else: ?>
            <?php $__currentLoopData = $s->arquivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                <img class="img-fluid" style="height: 50%; width:60%;" src="<?php echo e(url('storage/servicos/'.$i->arquivo)); ?>" alt="<?php echo e($s->nome); ?>">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls<?php echo e($s->id); ?>" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls<?php echo e($s->id); ?>" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="media-body">
        <h5 class="mt-0"><?php echo e($s->nome); ?></h5>
        <p>Descrição: <?php echo e($s->descricao); ?><br>
            Variação de preço: R$ <?php echo e($s->menor_preco); ?> ~ R$ <?php echo e($s->maior_preco); ?><br>
            Autônomo: <?php echo e(collect(explode(' ', $s->user->name))->slice(0, 3)->implode(' ')); ?></p>
        <a href="<?php echo e(url('servico/contratar/'.$s->id)); ?>" class="btn btn-primary" type="button">Contratar</a>
    </div>
</div>
<hr class="featurette-divider">

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>