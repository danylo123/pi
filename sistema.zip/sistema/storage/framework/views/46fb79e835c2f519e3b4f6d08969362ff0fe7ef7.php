<?php $__env->startSection('conteudo'); ?>

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-heading">
            <h2 class="display-4">Cadastre-se</h2>
        </div>
    </div>

    <div class="panel-body d-flex justify-content-center">
        <form class="form-horizontal col-md-8" method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-4 control-label">Nome</label>
                <div class="col-md-12">
                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                    <?php if($errors->has('name')): ?>
                    <span class="help-block" style="color: red">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-group<?php echo e($errors->has('cpf') ? ' has-error' : ''); ?>">
                <label for="cpf" class="col-md-4 control-label">CPF</label>

                <div class="col-lg-12">
                    <input id="cpf" type="text" class="form-control cpf" name="cpf" value="<?php echo e(old('cpf')); ?>" required>

                    <?php if($errors->has('cpf')): ?>
                    <span class="help-block" style="color: red">
                        <strong><?php echo e($errors->first('cpf')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('telefone') ? ' has-error' : ''); ?>">
                <label for="telefone" class="col-md-4 control-label">Telefone</label>

                <div class="col-md-12">
                    <input id="telefone" type="text" class="form-control phone" name="telefone" maxlength="11" value="<?php echo e(old('telefone')); ?>" required>

                    <?php if($errors->has('telefone')): ?>
                    <span class="help-block" style="color: red">
                        <strong><?php echo e($errors->first('telefone')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email" class="col-md-4 control-label">E-Mail</label>

                <div class="col-md-12">
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                    <?php if($errors->has('email')): ?>
                    <span class="help-block" style="color: red">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <label for="password" class="col-md-4 control-label">Senha</label>

                <div class="col-md-12">
                    <input id="password" type="password" class="form-control" name="password" required>

                    <?php if($errors->has('password')): ?>
                    <span class="help-block" style="color: red">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <label for="password-confirm" class="col-md-12 control-label">Confirme a senha</label>

                <div class="col-md-12">
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-12 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        Cadastrar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>