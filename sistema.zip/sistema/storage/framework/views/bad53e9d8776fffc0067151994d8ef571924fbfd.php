<?php $__env->startSection('titulo'); ?>
AMIGOS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

<table>
    <tr>
        <td><?php echo e($amigo['nome']); ?></td>
        <td><?php echo e($amigo['idade']); ?></td>
    </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>