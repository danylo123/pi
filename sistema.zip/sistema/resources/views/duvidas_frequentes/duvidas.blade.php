@extends('app')

@section('titulo')
Dúvidas frequentes
@stop

@section('conteudo')
<h1>Dúvidas frequentes</h1>
@stop