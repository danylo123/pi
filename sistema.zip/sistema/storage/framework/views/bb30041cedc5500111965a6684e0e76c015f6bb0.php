<?php $__env->startSection('titulo'); ?>
Ouvidoria
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<?php $__currentLoopData = $ouvidoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1>Chamado #<?php echo e($o->id); ?></h1>
<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <form method="post">
                <div class="form-row">
                    <div class="col-md-3">
                        <label><b>Usuário:</b> <?php echo e($o->user->name); ?></label>
                    </div>
                    <div class="col-md-3">
                        <label><b>Estato:</b> <?php echo e($o->estado); ?></label>
                    </div>
                    <div class="col-md-3">
                        <label><b>Aberto em:</b> <?php echo e(date_format($o->created_at, "d/m/Y H:i:s")); ?></label>
                    </div>
                    <?php if($o->estado == "Concluido"): ?>
                    <div class="col-md-3">
                        <label><b>Concluído em:</b> <?php echo e(date_format($o->updated_at, "d/m/Y H:i:s")); ?></label>
                    </div>
                    <?php endif; ?>
                    <div class="form-group col-md-12"><label for="assunto"><b>Assunto</b></label>
                        <input type="text" class="form-control" readonly value="<?php echo e($o->assunto); ?>" id="assunto" name="assunto" placeholder="Assunto" required>
                    </div>
                    <div class="form-group col-md-12"><label for="observacao"><b>Observação</b></label>
                        <textarea class="form-control" id="observacao" readonly cols="10" rows="5" required><?php echo e($o->observacao); ?></textarea>
                    </div>
                    <?php if($o->estado == "Concluido"): ?>
                    <div class="form-group col-md-12"><label for="observacao"><b>Resposta</b></label>
                        <textarea class="form-control" id="observacao" readonly cols="10" rows="5" required><?php echo e($o->resposta); ?></textarea>
                    </div>
                    <?php endif; ?>
            </form>
            <?php if($o->estado != "Concluido"): ?>
            <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#confirm<?php echo e($o->id); ?>">Responder</button>
            <div class="modal fade" id="confirm<?php echo e($o->id); ?>" role="dialog">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form method="post" action="<?php echo e(url('ouvidoria/chamado/resposta/update')); ?>">
                                <div class="form-row">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($o->id); ?>">
                                    <div class="form-group col-md-12"><label for="resposta">Resposta</label>
                                        <textarea class="form-control" id="resposta" name="resposta" required></textarea>
                                    </div>
                                    <div class="form-group col-md-12"><label for="resposta">Estado</label>
                                        <select class="form-control" id="estado" name="estado" required>
                                            <option value="Concluido">Concluido</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                </div><button type="submit" class="btn btn-primary">Enviar</button>
                            </form>

                        </div>
                        <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-default">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>