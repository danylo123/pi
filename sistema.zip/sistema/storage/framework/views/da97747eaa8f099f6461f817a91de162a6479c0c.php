<?php $__env->startSection('titulo'); ?>
SOBRE MIM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Meu nome é <?php echo e($eu['nome']); ?></h1>
<h2>Tenho <?php echo e($eu['idade']); ?> anos</h2>
<h2>Tenho <?php echo e($eu['id']); ?> Id</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>