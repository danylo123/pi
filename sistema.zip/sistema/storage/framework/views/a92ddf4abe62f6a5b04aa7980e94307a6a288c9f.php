<?php $__env->startSection('titulo'); ?>
Ouvidoria
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Administrar chamados ouvidoria</h1>
<div class="masonry-item col-md-12">

</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="bgc-white bd bdrs-3 p-20 mB-20 table-responsive-sm">
                <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Cód.</th>
                            <th>Assunto</th>
                            <th>Estado</th>
                            <th>Resposta</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ouvidoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($o->id); ?></td>
                            <td><?php echo e($o->assunto); ?></td>
                            <td><?php echo e($o->estado); ?></td>
                            <td><?php if($o->resposta == null): ?>
                                Sem resposta
                                <?php else: ?>
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#confirm<?php echo e($o->id); ?>">Visualizar</button>
                                <div class="modal fade" id="confirm<?php echo e($o->id); ?>" role="dialog">
                                    <div class="modal-dialog modal-md">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="form-group "><label for="resposta">Resposta</label>
                                                    <textarea class="form-control" readonly id="resposta" name="resposta" required><?php echo e($o->resposta); ?> em: <?php echo e(date_format($o->updated_at, "d/m/Y H:i:s")); ?>

                                                    </textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" data-dismiss="modal" class="btn btn-default">Cancelar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>