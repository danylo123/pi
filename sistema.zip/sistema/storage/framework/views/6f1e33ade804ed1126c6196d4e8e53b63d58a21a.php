<?php $__env->startSection('titulo'); ?>
Documentos GE
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Documentos GE</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>