<?php $__env->startSection('titulo'); ?>
Ouvidoria
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Ouvidoria</h1>
<div class="masonry-item col-md-12">
    <div class="bgc-white p-20 bd">
        <div class="mT-30">
            <form method="post" action="<?php echo e(url('ouvidoria/store')); ?>">
                <div class="form-row">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                    <div class="col-md-12">
                        <a href="<?php echo e(url('ouvidoria/chamado/respostas/'.auth()->user()->id)); ?>" class="btn cur-p btn-primary float-right">Visualizar meus tickets</a>
                    </div>
                    <div class="form-group col-md-12"><label for="assunto">Assunto</label>
                        <input type="text" class="form-control" id="assunto" name="assunto" placeholder="Assunto" required>
                    </div>
                    <div class="form-group col-md-12"><label for="observacao">Observação</label>
                        <textarea class="form-control" id="observacao" name="observacao" cols="20" rows="10" required></textarea>
                    </div>
                </div>
                <div class="form-group">
                </div><button type="submit" class="btn btn-primary">Enviar</button>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>